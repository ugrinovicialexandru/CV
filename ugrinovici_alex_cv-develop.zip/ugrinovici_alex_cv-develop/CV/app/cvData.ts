export class CvComponent {
    cvData = {
      fname: 'firstName',
      lname: 'lastName',
      email: 'email',
      contact: 'Phone (+373..)',
      skills: ['Skill 1', 'Skill 2', 'Skill 3']
    };
  }