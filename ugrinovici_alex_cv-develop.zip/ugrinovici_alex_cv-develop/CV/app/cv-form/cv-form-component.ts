import { Component } from '@angular/core';

@Component({
  selector: 'app-cv-form',
  templateUrl: './cv-form.component.html',
  styleUrls: ['./cv-form.component.css']
})
export class CvFormComponent {
  name: string;
 

  submitForm() {

  }
}
